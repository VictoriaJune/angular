

# AngularFixerUpper

This project was generated using [Nx](https://nx.dev).

## Fixer Upper Scenario

This is my first time using Angular.

I haven't done web dev for three years and have tried my best.

:)