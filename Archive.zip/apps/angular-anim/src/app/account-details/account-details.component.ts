import {ChangeDetectionStrategy, Component, OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {Account} from "@angular-anim/shared/services";
import {AccountService} from "@angular-anim/shared/services";
import { Location } from '@angular/common';

@Component({
  selector: 'angular-anim-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
// export class AccountDetailsComponent implements OnInit{
//   account: Account | undefined;
//
//   constructor(
//     private route: ActivatedRoute,
//     private accountService: AccountService
//   ) {}
//
//
//   ngOnInit(): void {
//     this.getAccount();
//   }
//
//   getAccount(): void {
//     const id = Number(this.route.snapshot.paramMap.get('id'));
//     this.accountService.getAccount(id)
//       .subscribe(account => this.account = account);
//   }
// }
export class AccountDetailsComponent implements OnInit{
  account: Account = {
    id:'',
    balance: 0,
    currency: ''
  };
  accounts: Account[] = [];
  id: string | null | undefined
  constructor(private route: ActivatedRoute,
              private accountService: AccountService,
              private location: Location
              ){}

  ngOnInit() {

    this.route.paramMap.subscribe(params => {
      this.id = params.get('id');
    })

    this.accountService.getAccounts().subscribe((accounts: Account[]) => {
      accounts.forEach(e => {
        if (e.id === this.id ){
          this.account = e;
        }
      })
    });
  }

  goBack(): void {
    this.location.back();
  }

}
