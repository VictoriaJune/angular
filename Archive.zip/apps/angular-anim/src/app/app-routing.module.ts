import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import {AccountSummaryComponent} from "@angular-anim/feature/account-summary";

// TODO: 2. We've setup these routes and have them on the page but they aren't working
const routes: Routes = [
  { path: '', component: AccountSummaryComponent },
  { path: 'account/:id', component: AccountDetailsComponent },
  { path: 'about', component: AboutComponent }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes),
  ],
  declarations: [],
  exports: [RouterModule]
})
export class AppRoutingModule { }
