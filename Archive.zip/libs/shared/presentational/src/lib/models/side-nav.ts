export interface SideNavItem {
  title: string,
  subtitle: string,
  link: string,
}