# feature-presentational

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test feature-presentational` to execute the unit tests.
