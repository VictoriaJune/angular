export interface Sample {
  prop1: string;
}